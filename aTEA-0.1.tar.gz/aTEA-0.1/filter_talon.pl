#!/usr/bin/perl
use strict;
use warnings;
use Getopt::Long;

my ($talon_tsv, $known_trans_reads, $novel_trans_reads, $novel_gene_reads, $reads_cutoff_stage, $stage_number) = ($ARGV[0],1,2,2,2,2);

GetOptions(
    'talon_tsv=s' => \$talon_tsv,
    'known_trans_reads=i' => \$known_trans_reads,
    'novel_trans_reads=s' => \$novel_trans_reads,
    'novel_gene_reads=s' => \$novel_gene_reads,
    'reads_cutoff_stage=s' => \$reads_cutoff_stage,
    'stage_number=s' => \$stage_number,
);

if (!defined $talon_tsv && !defined $known_trans_reads && !defined $novel_trans_reads && !defined $novel_gene_reads) {
    die "Error: At least one option must be provided.\n Usage: perl 02_filter_talon.pl --talon_tsv mouse_all_talon_abundance_filtered.tsv --known_trans_reads 1 --novel_trans_reads 2 --novel_gene_reads 2 ";
}

open IN, "$talon_tsv" or die $!;
open OUT, ">$talon_tsv.hc";
while (<IN>) {
	if(/^gene_ID/){
		print OUT "$_";
		next;
	}
	chomp;
	my $line=$_;
	my @arr=split("\t",$line);
	my @count=@arr[11..$#arr];
	## for known transcripts, we require supporting reads >=1 by HQ reads
	if ($arr[8] eq "Known" and $arr[9] eq "Known") {
		my $sample_support=0;
		for (my $n = 0; $n < $#count; $n+=2) {
			if ($count[$n]>=$known_trans_reads) {
				$sample_support++;
			}
		}
		if ($sample_support>=1) {
			print OUT "$line\n";
		}
	}
	## for novel genes, we require supporting reads >=2, then we manually curate the models
	elsif ($arr[8] eq "Intergenic") {
		my $sample_support=0;
		for (my $n = 0; $n < $#count; $n+=2) {
			if ($count[$n]>=$novel_gene_reads) {
				$sample_support++;
			}
		}
		if ($sample_support>=1) {
			print OUT "$line\n";
		}
	}
	## for novel transcripts, we require supporting reads >=3, which also guraatee cpm>=1 in all samples
	else{
		my $sample_support=0;
		for (my $n = 0; $n < $#count; $n+=2) {
			if ($count[$n]>=$novel_trans_reads) {
				$sample_support++;
			}
		}
		if ($sample_support>=1) {
			print OUT "$line\n";
		}
	}
}
close IN;
close OUT;

## combine the reads for each sample from hq and lq 

open IN, "$talon_tsv.hc" or die $!;
open OUT, ">$talon_tsv.hc.lc.combined";
while (<IN>) {
	if(/^gene_ID/){
		my @arr=split("\t",$_);
		print OUT "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\t$arr[8]\t$arr[9]\t$arr[10]\t";
		my @count=@arr[11..$#arr];
		for (my $n = 0; $n < $#count; $n+=2) {
			$count[$n]=~s/hq/combined/;
			print OUT "$count[$n]\t";
		}
		print OUT "\n";
		next;
	}
	chomp;
	my @arr=split("\t",$_);
	print OUT "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\t$arr[8]\t$arr[9]\t$arr[10]\t";
	my @count=@arr[11..$#arr];
	for (my $n = 0; $n < $#count; $n+=2) {
		my $sum=$count[$n]+$count[$n+1];
		print OUT "$sum\t";
	}
	print OUT "\n";
}
close IN;
close OUT;

## filter lowly expressed transcripts with combined reads: at least 2 reads at one stage or at least two stage with >=1 reads

open IN, "$talon_tsv.hc.lc.combined" or die $!;
open OUT, ">$talon_tsv.hc.lc.combined.filterlow";
while (<IN>) {
	if(/^gene_ID/){
		print OUT "$_";
		next;
	}
	chomp;
	my $line=$_;
	my @arr=split("\t",$_);
	my @count=@arr[11..$#arr];
	my $stage_1=0;
	my $stage_2=0;
	foreach my $a (@count){
		if ($a>=1) {
			$stage_1++;
		}
		if ($a>=2) {
			$stage_2++;
		}
	}
	if ($stage_1>=2 or $stage_2>=1) {
		print OUT "$line\n";
	}
}
close IN;
close OUT;


### generate GTF and transcripts

`cut -f 1,2 $talon_tsv.hc.lc.combined.filterlow | sed '1d' | sed 's/\t/,/' > talon_final_id.list`;
#`cut -f 1,2 mouse_all_talon_abundance_filtered.tsv.hc.lc.combined.filterlow | sed '1d' | sed 's/\t/,/' > talon_final_id.list`;

`talon_create_GTF --whitelist talon_final_id.list --db talon.db -a GRCz11_annot --build GRCz11 --o final`;
`~/local/gffread/gffread  -w final_talon.transcripts.fa -g GRCz11.fa final_talon.gtf`;



