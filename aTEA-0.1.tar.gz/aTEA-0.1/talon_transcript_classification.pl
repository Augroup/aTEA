#!/usr/bin/perl
use strict;
use warnings;

## this script is used to classify talon transcripts into TE, TE-gene chimeric and gene

## transcript-TE overlap shreshold: TE >80% overlaps and first exon must be covered by TE; gene transcripts do not contain any TE sequences, others are TE-gene chimeric transcripts

open IN, "Demo_transcript_output_exon.tsv" or die $!;
my @whole=<IN>;
chomp @whole;
close IN;

open IN, "Demo_transcript_output";
open OUT, ">Demo_transcript_output.format";
while (<IN>) {
	chomp;
	if (/^isoform/) {
		print OUT "$_\tNumber_of_exon_overlap_TE\tFirstExon\tall_exon_overlap\tNumber_of_TE_type\tTE_subfamily\n";
		next;
	}
	my $line=$_;
	my @arr=split("\t",$line);
	if ($arr[2] eq "NA") {
		print OUT "$line\tNA\tNA\tNA\tNA\tNA\n";
		next;
	}

	my @grep= grep /$arr[0]/,@whole;
	my @exon=();
	my @te=();
	my $firstexon="NO";
	foreach my $each (@grep){
		my @tmp=split("\t",$each);
		if ($tmp[1]==1) {
			$firstexon="YES";
		}
		push @exon,$tmp[1];
		$tmp[3]=~s/_dup\d+//g;
		if ($tmp[3]=~";") {
			my @part=split(";",$tmp[3]);
			foreach $b (@part){
				push @te, $b;
			}
		}
		else{
			push @te,$tmp[3];
		}
	}
	my $exon=@exon;
	my $exon_all=join(";", @exon);
	my @te_u=uniq(@te);
	my $te_u=@te_u;
	my $te_all=join(";",@te_u);
	print OUT "$line\t$firstexon\t$exon\t$exon_all\t$te_u\t$te_all\n";
	@grep=();
}

close IN;
close OUT;


open IN, "Demo_transcript_output.format" or die $!;
open OUT, ">Demo.TE.annotation.list2";
open OUT2, ">Demo.TE-Gene.annotation.list2";
open OUT3, ">Demo.Gene.annotation.list2";

while (<IN>) {
	if (/^isoform/) {
		print OUT "$_";
		print OUT2 "$_";
		print OUT3 "$_";
		next;
	}
	my $line=$_;
	my @arr=split("\t",$line);
	if ($arr[4] eq "NA") {
		print OUT3 "$line";
	}
	elsif ($arr[4]>=0.8 and $arr[10] eq "YES" ) {
		print OUT "$line";
	}
	else{
		print OUT2 "$line";
	}
}
close IN;
close OUT;
close OUT2;
close OUT3;


#`wc -l zebrafish_transcript_output.*.annotation.list`;
open IN, "Demo.TE.annotation.list2" or die $!;
open OUT, ">Demo.TE.sum";
my @gene=();
my @type=();
my @family=();
my @subfamily=();
while (<IN>) {
	next if (/^isoform/);
	chomp;
	my @arr=split("\t",$_);
	push @gene,$arr[1];
	push @type,$arr[9];
	push @family,$arr[8];
	push @subfamily,$arr[7];
}
close IN;

my @gene_u=uniq(@gene);
my $gene_u=@gene_u;
my @type_u=uniq(@type);
my $type_u=@type_u;
my @family_u=uniq(@family);
my $family_u=@family_u;
my @subfamily_u=uniq(@subfamily);
my $subfamily_u=@subfamily_u;

print OUT "$gene_u\n$type_u\n$family_u\n$subfamily_u\n";

close OUT;

sub uniq {
    my %seen;
    grep !$seen{$_}++, @_;
}



