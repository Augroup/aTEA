## TE annotation on transcript with RepeatMasker output

python TE_quantification/TE_quantification.py annot_select \
 -rptmsk GRCz11.TE.fa.out \
 -trans_annot final_talon.gtf \
 -o Demo.TE_overlap_with_transcript.gtf \
 -isoform_o Demo_transcript_output


 ## classify all transcript into TE-alone, TE-gene and gene transcripts

 perl talon_transcript_classification.pl 
