#!/usr/bin/perl

use strict;
use warnings;

## This script is to reverse complement pacbio reads

my @file=glob("*.lq.clean.fa");
foreach my $each (@file){
	my $name=$each;
	$name=~s/\.lq\.clean.fa//;
	open IN, "$each" or die $!;
	open OUT, ">$name.lq.clean.rc.fa";
	$/=">";
	while (<IN>) {
		next if (length $_ <2);
		s/>//;
		my @arr=split("\n",$_);
		my $name=shift @arr;
		my $new_name=$name."/rc";
		my $seq=join("",@arr);
		my $revcomp=reverse $seq;
		$revcomp=~tr/ATGCatgc/TACGtacg/;
		print OUT ">$new_name\n";
		print OUT "$revcomp\n";
	}
	close IN;
	close OUT;
	$/="\n";
}

