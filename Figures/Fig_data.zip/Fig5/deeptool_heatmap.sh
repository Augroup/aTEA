#H3K9me3

bamCompare -b1 h2_1_chip.uniq.sort.rmdup.bam -b2 h2_1_ctr.uniq.sort.rmdup.bam -o h2_1.uniq.log2ratio.bw \
--effectiveGenomeSize 1369631918 
bamCompare -b1 h4_1_chip.uniq.sort.rmdup.bam -b2 h4_1_ctr.uniq.sort.rmdup.bam -o h4_1.uniq.log2ratio.bw \
--effectiveGenomeSize 1369631918 
bamCompare -b1 h6_1_chip.uniq.sort.rmdup.bam -b2 h6_1_ctr.uniq.sort.rmdup.bam -o h6_1.uniq.log2ratio.bw \
--effectiveGenomeSize 1369631918 

computeMatrix scale-regions -p 8 \
-S h2_1.uniq.log2ratio.bw h4_1.uniq.log2ratio.bw h6_1.uniq.log2ratio.bw \
-R TE.TSS.bed \
-o TE_rep1.h3k9me3.uniq.log2ratio.gz \
-b 1000 \
-a 1000 \
--skipZeros \
--missingDataAsZero
plotHeatmap -m TE_rep1.h3k9me3.uniq.log2ratio.gz -out TE_rep1.h3k9me3.uniq.log2ratio.pdf --colorList 'white,blue' #--whatToShow 'heatmap and colorbar' 

# ATAC-seq

for i in cell64 cell256 cell1K high oblong sphere dome shield 80epiboly 

do
	## uniq 
	~/miniconda3/envs/biotools/bin/samtools sort -@ 10 -o $i.uniq.sort.bam  $i.uniq.sam2
	~/miniconda3/envs/biotools/bin/samtools index $i.uniq.sort.bam
	~/miniconda3/envs/gatk4/bin/gatk --java-options "-Xmx10g" MarkDuplicates -I $i.uniq.sort.bam -O $i.uniq.sort.rmdup.bam --REMOVE_DUPLICATES true --METRICS_FILE $i.uniq.metrics.txt
	~/miniconda3/envs/biotools/bin/samtools index  $i.uniq.sort.rmdup.bam

	bamCoverage -b $i.uniq.sort.rmdup.bam  -p 10 -o $i.uniq.sort.rmdup.bw \
	--normalizeUsing RPKM \
	--effectiveGenomeSize 1369631918  
done

computeMatrix scale-regions -p 10 \
-S cell64_1.uniq.sort.rmdup.bw cell256_1.uniq.sort.rmdup.bw cell1K_1.uniq.sort.rmdup.bw high_1.uniq.sort.rmdup.bw oblong_1.uniq.sort.rmdup.bw sphere_1.uniq.sort.rmdup.bw dome_1.uniq.sort.rmdup.bw shield_1.uniq.sort.rmdup.bw 80epiboly.uniq.sort.rmdup.bw  \
-R TE.TSS.bed \
-o TE.smRNA.uniq.gz \
-b 1000 \
-a 1000 \
--skipZeros \
--missingDataAsZero
plotHeatmap -m TE.smRNA.uniq.gz -out TE.smRNA.uniq.gz.pdf --colorList 'white,#C380CC' #--whatToShow 'heatmap and colorbar'   

# small RNA

for i in cell1 cell16 cell512 oblong 50epiboly 6somite 24hpf 48hpf

do
	## uniq 
	~/miniconda3/envs/biotools/bin/samtools sort -@ 10 -o $i.uniq.sort.bam  $i.uniq.sam2
	~/miniconda3/envs/biotools/bin/samtools index $i.uniq.sort.bam

	bamCoverage -b $i.uniq.sort.bam  -p 10 -o $i.uniq.sort.bw \
	--normalizeUsing RPKM \
	--effectiveGenomeSize 1369631918 
done

computeMatrix scale-regions -p 10 \
-S cell1.uniq.sort.bw cell16.uniq.sort.bw cell512.uniq.sort.bw oblong.uniq.sort.bw 50epiboly.uniq.sort.bw 6somite.uniq.sort.bw 24hpf.uniq.sort.bw 48hpf.uniq.sort.bw \
-R TE.TSS.bed \
-o TE.smRNA.uniq.gz \
-b 1000 \
-a 1000 \
--skipZeros \
--missingDataAsZero
plotHeatmap -m TE.smRNA.uniq.gz -out TE.smRNA.uniq.gz.pdf --colorList 'white,#C380CC' #--whatToShow 'heatmap and colorbar'   

# H3K4me3
# Liu et al study
bamCoverage -b SRR6729438.uniq.sorted.rmChrM.rmdup.bam  -p 4 -o sperm_H3K4me3_rep1.bw \
	--normalizeUsing RPKM \
	--effectiveGenomeSize 1369631918 
bamCoverage -b SRR6729439.uniq.sorted.rmChrM.rmdup.bam  -p 4 -o sperm_H3K4me3_rep2.bw \
	--normalizeUsing RPKM \
	--effectiveGenomeSize 1369631918 

bamCoverage -b SRR6729440.uniq.sorted.rmChrM.rmdup.bam  -p 4 -o oocyte_H3K4me3_rep1.bw \
	--normalizeUsing RPKM \
	--effectiveGenomeSize 1369631918 
bamCoverage -b SRR6729441.uniq.sorted.rmChrM.rmdup.bam  -p 4 -o oocyte_H3K4me3_rep2.bw \
	--normalizeUsing RPKM \
	--effectiveGenomeSize 1369631918

bamCoverage -b SRR6729442.uniq.sorted.rmChrM.rmdup.bam  -p 4 -o 2-cell_H3K4me3_rep1.bw \
	--normalizeUsing RPKM \
	--effectiveGenomeSize 1369631918 
bamCoverage -b SRR6729443.uniq.sorted.rmChrM.rmdup.bam  -p 4 -o 2-cell_H3K4me3_rep2.bw \
	--normalizeUsing RPKM \
	--effectiveGenomeSize 1369631918

bamCoverage -b SRR6729444.uniq.sorted.rmChrM.rmdup.bam  -p 4 -o 16-cell_H3K4me3_rep1.bw \
	--normalizeUsing RPKM \
	--effectiveGenomeSize 1369631918 
bamCoverage -b SRR6729445.uniq.sorted.rmChrM.rmdup.bam  -p 4 -o 16-cell_H3K4me3_rep2.bw \
	--normalizeUsing RPKM \
	--effectiveGenomeSize 1369631918

bamCoverage -b SRR6729446.uniq.sorted.rmChrM.rmdup.bam  -p 4 -o 128-cell_H3K4me3_rep1.bw \
	--normalizeUsing RPKM \
	--effectiveGenomeSize 1369631918 
bamCoverage -b SRR6729447.uniq.sorted.rmChrM.rmdup.bam  -p 4 -o 128-cell_H3K4me3_rep2.bw \
	--normalizeUsing RPKM \
	--effectiveGenomeSize 1369631918

bamCoverage -b SRR6729448.uniq.sorted.rmChrM.rmdup.bam  -p 4 -o 1K-cell_H3K4me3_rep1.bw \
	--normalizeUsing RPKM \
	--effectiveGenomeSize 1369631918 
bamCoverage -b SRR6729449.uniq.sorted.rmChrM.rmdup.bam  -p 4 -o 1K-cell_H3K4me3_rep2.bw \
	--normalizeUsing RPKM \
	--effectiveGenomeSize 1369631918


computeMatrix scale-regions -p 4 \
-S sperm_H3K4me3_rep1.bw sperm_H3K4me3_rep2.bw oocyte_H3K4me3_rep1.bw oocyte_H3K4me3_rep2.bw 2-cell_H3K4me3_rep1.bw 2-cell_H3K4me3_rep2.bw 16-cell_H3K4me3_rep1.bw 16-cell_H3K4me3_rep2.bw 128-cell_H3K4me3_rep1.bw 128-cell_H3K4me3_rep2.bw 1K-cell_H3K4me3_rep1.bw 1K-cell_H3K4me3_rep2.bw \
-R TE.TSS.bed \
-o TE.H3K4me3.uniq.gz \
-b 1000 \
-a 1000 \
--skipZeros \
--missingDataAsZero
plotHeatmap -m TE.H3K4me3.uniq.gz -out TE.H3K4me3.uniq.pdf --colorList 'white,#C380CC' #--whatToShow 'heatmap and colorbar' 

computeMatrix scale-regions -p 4 \
-S sperm_H3K4me3_rep1.bw sperm_H3K4me3_rep2.bw oocyte_H3K4me3_rep1.bw oocyte_H3K4me3_rep2.bw 2-cell_H3K4me3_rep1.bw 2-cell_H3K4me3_rep2.bw 16-cell_H3K4me3_rep1.bw 16-cell_H3K4me3_rep2.bw 128-cell_H3K4me3_rep1.bw 128-cell_H3K4me3_rep2.bw 1K-cell_H3K4me3_rep1.bw 1K-cell_H3K4me3_rep2.bw \
-R GRCz11.gene.bed \
-o Gene.H3K4me3.uniq.gz \
-b 1000 \
-a 1000 \
--skipZeros \
--missingDataAsZero
plotHeatmap -m Gene.H3K4me3.uniq.gz -out Gene.H3K4me3.uniq.pdf --colorList 'white,#C380CC' #--whatToShow 'heatmap and colorbar' 

## Xie study

computeMatrix scale-regions -p 4 \
-S oocyte_H3K4me3_rep1.bw oocyte_H3K4me3_rep2.bw dome_H3K4me3_rep1.bw dome_H3K4me3_rep2.bw \
-R ../../TE.TSS.bed \
-o TE.H3K4me3.uniq.gz \
-b 1000 \
-a 1000 \
--skipZeros \
--missingDataAsZero
plotHeatmap -m TE.H3K4me3.uniq.gz -out TE.H3K4me3.uniq.pdf --colorList 'white,#C380CC' #--whatToShow 'heatmap and colorbar' 

computeMatrix scale-regions -p 4 \
-S oocyte_H3K4me3_rep1.bw oocyte_H3K4me3_rep2.bw dome_H3K4me3_rep1.bw dome_H3K4me3_rep2.bw \
-R ../../Gene.TSS.bed \
-o Gene.H3K4me3.uniq.gz \
-b 1000 \
-a 1000 \
--skipZeros \
--missingDataAsZero
plotHeatmap -m Gene.H3K4me3.uniq.gz -out Gene.H3K4me3.uniq.pdf --colorList 'white,#C380CC' #--whatToShow 'heatmap and colorbar' 

# H3K27ac
computeMatrix scale-regions -p 4 \
-S oocyte_H3K27ac_rep1.bw 256cell_H3K27ac_rep1.bw dome_H3K27ac_rep1.bw  \
-R TE.TSS.bed \
-o TE.H3K27ac.uniq2.gz \
-b 1000 \
-a 1000 \
--skipZeros \
--missingDataAsZero
plotHeatmap -m TE.H3K27ac.uniq2.gz -out TE.H3K27ac.uniq2.pdf --colorList 'white,#92D050' #--whatToShow 'heatmap and colorbar' 

computeMatrix scale-regions -p 4 \
-S oocyte_H3K27ac_rep1.bw 256cell_H3K27ac_rep1.bw dome_H3K27ac_rep1.bw  \
-R Gene.TSS.bed \
-o Gene.H3K27ac.uniq2.gz \
-b 1000 \
-a 1000 \
--skipZeros \
--missingDataAsZero
plotHeatmap -m Gene.H3K27ac.uniq2.gz -out Gene.H3K27ac.uniq2.pdf --colorList 'white,#92D050' #--whatToShow 'heatmap and colorbar' 

