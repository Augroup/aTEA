library(ggplot2)
library(dplyr)


pdf("allstage_totalTPM_SR_LR.barplot.pdf",w=10,h=6)
data<-read.table("allstage_totalTPM_SR_LR.txt", header = TRUE, sep = "\t")
coeff <- 0.5
level_order <- factor(data$Stage, level = c("zygote","1-cell","2-cell","64-cell","128-cell","1k-cell","oblong","sphere","dome","shield", "75epiboly","1-4-somites","14-19-somites","20-25-somites","prim5","prim15","prim25","Long-pec","Protruding-mouth","day4","day5"))


ggplot(data, aes(x=level_order)) + 
  geom_bar( aes(y=SR / coeff), stat="identity", size=.1, fill="grey", color="grey", alpha=.9) +
  geom_line(aes(x=level_order,y=LR), size=1, color="#C00000",group = 1) + geom_point(aes(x=level_order,y=LR), color="#C00000",size=2)+
  #geom_line(aes(x=level_order, y=TPM / coeff), size=1, color="#B3697A",group = 1) + 
  scale_y_continuous(
    # Features of the first axis
    name = "Long Read",
    # Add a second axis and specify its features
    sec.axis = sec_axis(~.*coeff, name="Short Read"))+ 
    theme_classic()+

  theme(
    axis.text.x = element_text(color = "black", size=16, angle=90), axis.text.y = element_text(color = "#D12E43", size=16), axis.text.y.right = element_text(color = "grey", size=16),axis.title.y = element_text(color = "#C00000", size=16),
    axis.title.y.right = element_text(color = "grey", size=16)
  )+

  ggtitle("Total TPM over early embryonic development")+theme(plot.title = element_text(size = 18, face = "bold",hjust = 0.5))

 # p+scale_x_discrete(limits=c("fertilized","cell1","cell64","cell1k","high","oblong","sphere","dome","30epiboly","50epiboly","shield"))
  
dev.off()




