library(ggpubr)
library(dplyr) 
library(ggplot2)
theme_set(theme_pubclean())

pdf("TE_subfamily.cell1K.nuc_cyt.ratio.txt.4R.pdf")
alldata <- read.table("TE_subfamily.cell1K.nuc_cyt.ratio.txt.4R",header=T, sep="\t")
my_comparisons <- list( c("DNA", "LINE"), c("DNA", "LTR"), c("LTR", "LINE"))
p<-ggboxplot(alldata, x="Type", y="NC", fill = "Type",palette = c("#4289C8","#70AD47","#F3904A"),ggtheme = theme_pubclean())+
theme(axis.text.x = element_text(face="bold", color = "black", 
                           size=14, angle=0),
          axis.text.y = element_text(face="bold", color = "black", 
                           size=14, angle=0))
#scale_fill_manual(values=c('#999999','#E69F00', '#56B4E9'))

p+stat_compare_means(comparisons = my_comparisons)+
scale_x_discrete(limits=c("DNA", "LINE", "LTR"))
dev.off()


pdf("TE_subfamily.Dome.nuc_cyt.ratio.txt.4R.pdf")
alldata <- read.table("TE_subfamily.Dome.nuc_cyt.ratio.txt.4R",header=T, sep="\t")
my_comparisons <- list( c("DNA", "LINE"), c("DNA", "LTR"), c("LTR", "LINE"))
p<-ggboxplot(alldata, x="Type", y="NC", fill = "Type",palette = c("#4289C8","#70AD47","#F3904A"),ggtheme = theme_pubclean())+
theme(axis.text.x = element_text(face="bold", color = "black", 
                           size=14, angle=0),
          axis.text.y = element_text(face="bold", color = "black", 
                           size=14, angle=0))
#scale_fill_manual(values=c('#999999','#E69F00', '#56B4E9'))

p+stat_compare_means(comparisons = my_comparisons)+
scale_x_discrete(limits=c("DNA", "LINE", "LTR"))
dev.off()


pdf("TE_subfamily.Shield.nuc_cyt.ratio.txt.4R.pdf")
alldata <- read.table("TE_subfamily.Shield.nuc_cyt.ratio.txt.4R",header=T, sep="\t")
my_comparisons <- list( c("DNA", "LINE"), c("DNA", "LTR"), c("LTR", "LINE"))
p<-ggboxplot(alldata, x="Type", y="NC", fill = "Type",palette = c("#4289C8","#70AD47","#F3904A"),ggtheme = theme_pubclean())+
theme(axis.text.x = element_text(face="bold", color = "black", 
                           size=14, angle=0),
          axis.text.y = element_text(face="bold", color = "black", 
                           size=14, angle=0))
#scale_fill_manual(values=c('#999999','#E69F00', '#56B4E9'))

p+stat_compare_means(comparisons = my_comparisons)+
scale_x_discrete(limits=c("DNA", "LINE", "LTR"))
dev.off()



