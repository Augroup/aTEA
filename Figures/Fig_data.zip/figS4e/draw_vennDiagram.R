#install.packages("VennDiagram")                       # Install VennDiagram package
library("VennDiagram")                                # Load VennDiagram package

pdf("zebrafish.LR_SR_vennDiagram.pdf")
grid.newpage()                                        # Move to new plotting page
draw.pairwise.venn(area1 = 9741,                        # Create pairwise venn diagram
                   area2 = 1817,
                   cross.area = 375,
                   category = c("SR", "LR"),
                   #col = "grey",
                   lty = "blank",
                   cex=0,
                   ext.text=FALSE,
                   cat.cex=0,
                   alpha = 0.8,
                   fill = c("#D9D9D9","#E87D72"))
dev.off()


pdf("mouse.LR_SR_vennDiagram.pdf")
grid.newpage()                                        # Move to new plotting page
draw.pairwise.venn(area1 = 25935,                        # Create pairwise venn diagram
                   area2 = 1448,
                   cross.area = 379,
                   category = c("SR", "LR"),
                   #col = "grey",
                   lty = "blank",
                   cex=0,
                   ext.text=FALSE,
                   cat.cex=0,
                    alpha = 0.8,
                   fill = c("#D9D9D9","#E87D72"))
dev.off()



