library(ggplot2)
#library(tidyverse)

### including poly0=0
pdf("Isoform.exp.polya_ribo0.log2T.scatterplot.2.pdf",w=10,h=10)
data <- read.table("Isoform.exp.polya_ribo0.log2T.v3.4R", header = TRUE, sep = "\t")
data$Stage<-factor(data$Stage, levels=c("0h","1h","2h","3h","4h","5h","6h","7h","8h"))
ggplot(data, aes(x=PolyA, y=Ribo0,color=Class)) + 
  geom_point(alpha=0.90,size=2.2)+
  #scale_x_continuous( breaks = c(0, 50, 100))+
  #scale_y_continuous( breaks = c(0, 50, 100))+
  scale_color_manual(values=c('#cdd1cd','#289123','#FF0000'))+
  facet_wrap(~data$Stage, ncol=3, scales = "fixed") +
  theme_classic()+
  theme(strip.text = element_text(color = "black",size=10))
dev.off()

