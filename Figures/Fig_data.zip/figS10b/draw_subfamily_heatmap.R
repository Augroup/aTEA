library(ggplot2)
library(RColorBrewer)
library(pheatmap)
library(gplots)
#library (vegan)
#library(viridis)
#library(ComplexHeatmap)


paletteLength <- 50
myColor2 <- colorRampPalette(c("#40ACAA","white", "#D79495"))(paletteLength)



pdf("DNA.subfamily.Heatmap.pdf",w=8,h=12)
annotation_row<-read.table("DNA_subfamily_annotation",header=T,sep="\t",,row.names=1)
annotation_row <- as.data.frame(annotation_row)
mydata <- read.table("DNA.subfamily.CPM4Heatmap", header=T, sep="\t",row.names=1)
pheatmap(mydata, scale = "row", color = myColor2, cluster_cols=FALSE, annotation_row = annotation_row, cellwidth = 20)
dev.off()


pdf("LTR.subfamily.Heatmap.pdf",w=10,h=20)
annotation_row<-read.table("LTR_subfamily_annotation",header=T,sep="\t",,row.names=1)
annotation_row <- as.data.frame(annotation_row)
mydata <- read.table("LTR.subfamily.CPM4Heatmap", header=T, sep="\t",row.names=1)
pheatmap(mydata, scale = "row",color = myColor2, cluster_cols=FALSE, annotation_row = annotation_row, cellwidth = 10)
dev.off()


pdf("LINE.subfamily.Heatmap.pdf",w=8,h=12)
annotation_row<-read.table("LINE_subfamily_annotation",header=T,sep="\t",,row.names=1)
annotation_row <- as.data.frame(annotation_row)
mydata <- read.table("LINE.subfamily.CPM4Heatmap", header=T, sep="\t",row.names=1)
pheatmap(mydata, scale = "row", color = myColor2, cluster_cols=FALSE, annotation_row = annotation_row, cellwidth = 20)
dev.off()




