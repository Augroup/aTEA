# library
library(ggplot2)
 
 
 pdf("TE_family_percentage_dif_stages.order.pdf",w=8,h=6)
data <- read.table("TE_class_percentage.txt",header = TRUE, sep = "\t")
# Stacked + percent
ggplot(data, aes(fill=Family, y=TPM, x=Stage)) + 
scale_fill_manual(values = c("#4289C8","#70AD47","#F3904A")) +
    geom_bar(position="fill", stat="identity")+theme_classic()+theme(axis.text.x = element_text(color = "black", #face="bold",
                           size=22, angle=90),
          axis.text.y = element_text(color = "black",  #face="bold",
                           size=28, angle=0))+
    scale_x_discrete(limits=c("Fertilized egg","1-cell","64-cell","1k-cell","High","Oblong","Sphere","Dome","30%epiboly","50%epiboly","Shield"))
 dev.off()

