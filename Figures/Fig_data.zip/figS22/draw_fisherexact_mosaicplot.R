

#DNA
pdf("DNA.SD_vs_transposition.mosaicplot.pdf")
table <- data.frame( sd = c(76,34), transposition = c(347,59),
      row.names = c("total","DNA"))

mosaicplot(table,color =c("white","#3D8AD5"), border = "#3D8AD5")

dev.off()

fisher.test(table)


#LINE
pdf("LINE.SD_vs_transposition.mosaicplot.pdf")
table <- data.frame( sd = c(76,7), transposition = c(347,64),
      row.names = c("total","LINE"))

mosaicplot(table, color =c("white","#477C44"), border = "#477C44")

dev.off()

fisher.test(table)


#LTR
pdf("LTR.SD_vs_transposition.mosaicplot.pdf")
table <- data.frame( sd = c(76,35), transposition = c(347,224),
      row.names = c("total","LTR"))

mosaicplot(table,color =c("white","#F18F48"), border = "#F18F48")

dev.off()

fisher.test(table)