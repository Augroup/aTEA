#install.packages("RIdeogram")

library(RIdeogram)

#setwd("/Users/li243/OSUMC/my_project/TE_activation/00_work_dir/01_TE_transcript_identification_quantification/00_gene_density")

human_karyotype <- read.table("GRCz11.karyotype.txt", sep = "\t", header = T, stringsAsFactors = F)
Random_RNAs_500 <- read.table("active_TE_position_new.NoSINE", sep = "\t", header = T, stringsAsFactors = F)
gene_density <- read.table("gene_ct_500Kb.txt", sep = "\t", header = T, stringsAsFactors = F)

ideogram(karyotype = human_karyotype, overlaid = gene_density, label = Random_RNAs_500, label_type = "marker")
convertSVG("chromosome.svg", device = "png")
