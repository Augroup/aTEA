library(ggplot2)
library(RColorBrewer)
library(pheatmap)
library(gplots)
library (vegan)
library(viridis)
#library(ComplexHeatmap)

paletteLength <- 50
myColor2 <- colorRampPalette(c("#EBEBEB","white", "#FFE949"))(paletteLength)
pdf("ERV_core_domain.sum.Heatmap.2.pdf",w=6,h=6)
#annotation_row<-read.table("DNA_subfamily_annotation",header=T,sep="\t",,row.names=1)
#annotation_row <- as.data.frame(annotation_row)
mydata <- read.table("ERV_core_domain.sum.4R", header=T, sep="\t")
pheatmap(mydata, scale = "none", color = myColor2, border_color = "#EBEBEB", cluster_cols=FALSE,cluster_rows=FALSE)
dev.off()


paletteLength <- 50
myColor2 <- colorRampPalette(c("#EBEBEB","white", "#FFCB49"))(paletteLength)
pdf("LTR_core_domain.sum.4R.Heatmap.2.pdf",w=6,h=6)
#annotation_row<-read.table("DNA_subfamily_annotation",header=T,sep="\t",,row.names=1)
#annotation_row <- as.data.frame(annotation_row)
mydata <- read.table("LTR_core_domain.sum.4R", header=T, sep="\t")
pheatmap(mydata, scale = "none", color = myColor2, border_color = "#EBEBEB",cluster_cols=FALSE,cluster_rows=FALSE)
dev.off()

paletteLength <- 50
myColor2 <- colorRampPalette(c("#EBEBEB","white", "#3D8AD5"))(paletteLength)
pdf("DNA_core_domain.sum.4R.Heatmap.2.pdf",w=6,h=6)
#annotation_row<-read.table("DNA_subfamily_annotation",header=T,sep="\t",,row.names=1)
#annotation_row <- as.data.frame(annotation_row)
mydata <- read.table("DNA_core_domain.sum.4R", header=T, sep="\t")
pheatmap(mydata, scale = "none", color = myColor2, border_color = "#EBEBEB",cluster_cols=FALSE,cluster_rows=FALSE)
dev.off()


paletteLength <- 50
myColor2 <- colorRampPalette(c("#EBEBEB","white", "#F18F48"))(paletteLength)
pdf("LINE_core_domain.sum.4R.Heatmap.2.pdf",w=6,h=6)
#annotation_row<-read.table("DNA_subfamily_annotation",header=T,sep="\t",,row.names=1)
#annotation_row <- as.data.frame(annotation_row)
mydata <- read.table("LINE_core_domain.sum.4R", header=T, sep="\t")
pheatmap(mydata, scale = "none", color = myColor2, border_color = "#EBEBEB", cluster_cols=FALSE,cluster_rows=FALSE)
dev.off()