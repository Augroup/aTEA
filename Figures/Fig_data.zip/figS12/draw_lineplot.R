library(ggplot2)
#library(tidyverse)

pdf("BHIKHARI_I.boxplotWithLines.pdf",w=6,h=4)
mydata <- read.table("BHIKHARI_I.4R", header=T, sep="\t")
ggplot(data = mydata,aes(x=Stage,y=TPM, group=TE_trans))+ 
#geom_boxplot(aes(x=Stage,y=TPM,group=Stage),colour="black",alpha=0.5,outlier.shape = NA)+
geom_line(linewidth = 1,alpha=0.8,colour="#ED7D31") +
geom_point(size=0.5,alpha=0.5,color = "black")+ 
#scale_x_discrete(limits=c("fertilized egg","1-cell","64-cell","1k-cell","high","oblong","sphere","dome","30%-epiboly","50%-epiboly","shield"))+
scale_x_discrete(limits=c("1k-cell","high","oblong","sphere","dome","30%-epiboly","50%-epiboly","shield"))+

theme_bw()+
theme(axis.text.x = element_text(color = "black", #face="bold",
                           size=10, angle=0),
          axis.text.y = element_text(color = "black",  #face="bold",
                           size=10, angle=0))
dev.off()


pdf("ERV2_DR-I.boxplotWithLines.pdf",w=6,h=4)
mydata <- read.table("ERV2_DR-I.4R", header=T, sep="\t")
ggplot(data = mydata,aes(x=Stage,y=TPM, group=TE_trans))+ 
#geom_boxplot(aes(x=Stage,y=TPM,group=Stage),colour="black",alpha=0.5,outlier.shape = NA)+
geom_line(linewidth = 1,alpha=0.8,colour="#ED7D31") +
geom_point(size=0.5,alpha=0.5,color = "black")+ 
#scale_x_discrete(limits=c("fertilized egg","1-cell","64-cell","1k-cell","high","oblong","sphere","dome","30%-epiboly","50%-epiboly","shield"))+
scale_x_discrete(limits=c("1k-cell","high","oblong","sphere","dome","30%-epiboly","50%-epiboly","shield"))+

theme_bw()+
theme(axis.text.x = element_text(color = "black", #face="bold",
                           size=10, angle=0),
          axis.text.y = element_text(color = "black",  #face="bold",
                           size=10, angle=0))
dev.off()


pdf("Kolobok-1_DR.boxplotWithLines.pdf",w=6,h=4)
mydata <- read.table("Kolobok-1_DR.4R", header=T, sep="\t")
ggplot(data = mydata,aes(x=Stage,y=TPM, group=TE_trans))+ 
#geom_boxplot(aes(x=Stage,y=TPM,group=Stage),colour="black",alpha=0.5,outlier.shape = NA)+
geom_line(linewidth = 1,alpha=0.8,colour="#3D8AD5") +
geom_point(size=0.5,alpha=0.5,color = "black")+ 
#scale_x_discrete(limits=c("fertilized egg","1-cell","64-cell","1k-cell","high","oblong","sphere","dome","30%-epiboly","50%-epiboly","shield"))+
scale_x_discrete(limits=c("1k-cell","high","oblong","sphere","dome","30%-epiboly","50%-epiboly","shield"))+

theme_bw()+
theme(axis.text.x = element_text(color = "black", #face="bold",
                           size=10, angle=0),
          axis.text.y = element_text(color = "black",  #face="bold",
                           size=10, angle=0))
dev.off()

pdf("EnSpm-2_DR.boxplotWithLines.pdf",w=6,h=4)
mydata <- read.table("EnSpm-2_DR.4R", header=T, sep="\t")
ggplot(data = mydata,aes(x=Stage,y=TPM, group=TE_trans))+ 
#geom_boxplot(aes(x=Stage,y=TPM,group=Stage),colour="black",alpha=0.5,outlier.shape = NA)+
geom_line(linewidth = 1,alpha=0.8,colour="#3D8AD5") +
geom_point(size=0.5,alpha=0.5,color = "black")+ 
#scale_x_discrete(limits=c("fertilized egg","1-cell","64-cell","1k-cell","high","oblong","sphere","dome","30%-epiboly","50%-epiboly","shield"))+
scale_x_discrete(limits=c("1k-cell","high","oblong","sphere","dome","30%-epiboly","50%-epiboly","shield"))+

theme_bw()+
theme(axis.text.x = element_text(color = "black", #face="bold",
                           size=10, angle=0),
          axis.text.y = element_text(color = "black",  #face="bold",
                           size=10, angle=0))
dev.off()


pdf("L2-1_DR.boxplotWithLines.pdf",w=6,h=4)
mydata <- read.table("L2-1_DR.4R", header=T, sep="\t")
ggplot(data = mydata,aes(x=Stage,y=TPM, group=TE_trans))+ 
#geom_boxplot(aes(x=Stage,y=TPM,group=Stage),colour="black",alpha=0.5,outlier.shape = NA)+
geom_line(linewidth = 1,alpha=0.8,colour="#70AD47") +
geom_point(size=0.5,alpha=0.5,color = "black")+ 
#scale_x_discrete(limits=c("fertilized egg","1-cell","64-cell","1k-cell","high","oblong","sphere","dome","30%-epiboly","50%-epiboly","shield"))+
scale_x_discrete(limits=c("1k-cell","high","oblong","sphere","dome","30%-epiboly","50%-epiboly","shield"))+

theme_bw()+
theme(axis.text.x = element_text(color = "black", #face="bold",
                           size=10, angle=0),
          axis.text.y = element_text(color = "black",  #face="bold",
                           size=10, angle=0))
dev.off()



pdf("L2-2_DRe.boxplotWithLines.pdf",w=6,h=4)
mydata <- read.table("L2-2_DRe.4R", header=T, sep="\t")
ggplot(data = mydata,aes(x=Stage,y=TPM, group=TE_trans))+ 
#geom_boxplot(aes(x=Stage,y=TPM,group=Stage),colour="black",alpha=0.5,outlier.shape = NA)+
geom_line(linewidth = 1,alpha=0.8,colour="#70AD47") +
geom_point(size=0.5,alpha=0.5,color = "black")+ 
#scale_x_discrete(limits=c("fertilized egg","1-cell","64-cell","1k-cell","high","oblong","sphere","dome","30%-epiboly","50%-epiboly","shield"))+
scale_x_discrete(limits=c("1k-cell","high","oblong","sphere","dome","30%-epiboly","50%-epiboly","shield"))+

theme_bw()+
theme(axis.text.x = element_text(color = "black", #face="bold",
                           size=10, angle=0),
          axis.text.y = element_text(color = "black",  #face="bold",
                           size=10, angle=0))
dev.off()




