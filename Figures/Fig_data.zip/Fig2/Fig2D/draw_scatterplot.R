library(ggplot2)
#library(tidyverse)


# Set the output PDF file
pdf("Aman_4hpf_vs_WT_4hpf.scatter.pdf", w = 8, h = 6)

# Read your data from the file
data <- read.table("Aman_4hpf_vs_WT_4hpf.scatter.txt", header = TRUE, sep = "\t")

data1 <- data[data$WT >= 1 & data$Class != "Maternal_gene", ]
data2 <-rbind (data[data$Class == "Maternal_gene", ], data1)

# Create the scatter plot with different alpha values
ggplot(data2, aes(x = WT, y = Mutant, color = Class)) +
  geom_point(aes(alpha = Class), size = 4) +
  scale_color_manual(values = c('grey','#B02418','#000000')) +
  scale_alpha_manual(values = c(0.1, 0.8, 0.8)) +
  scale_x_continuous( breaks = c(0, 2,4,6,8,10,12,14))+
  scale_y_continuous( breaks = c(0, 2,4,6,8,10,12,14))+
  geom_abline(lty = 1) +
  #scale_alpha_manual(values = c('grey' = 0.1, '#E69F00' = 1, '#000000' = 1)) +  # Map alpha values to Class
  theme_classic()+ coord_fixed()

# Save the plot to the PDF file
dev.off()


# Set the output PDF file
pdf("Aman_6hpf_vs_WT_6hpf.scatter.pdf", w = 8, h = 6)

# Read your data from the file
data <- read.table("Aman_6hpf_vs_WT_6hpf.scatter.txt", header = TRUE, sep = "\t")

# Create the scatter plot with different alpha values
ggplot(data, aes(x = WT, y = Mutant, color = Class)) +
  geom_point(aes(alpha = Class), size = 4) +
  scale_color_manual(values = c('grey','#B02418','#000000')) +
  scale_alpha_manual(values = c(0.1, 0.8, 0.8)) +
  scale_x_continuous( breaks = c(0, 2,4,6,8,10,12,14))+
  scale_y_continuous( breaks = c(0, 2,4,6,8,10,12,14))+
  geom_abline(lty = 1) +
  #scale_alpha_manual(values = c('grey' = 0.1, '#E69F00' = 1, '#000000' = 1)) +  # Map alpha values to Class
  theme_classic()+ coord_fixed()

# Save the plot to the PDF file
dev.off()


# Set the output PDF file
pdf("CHX_4hpf_vs_WT_4hpf.scatter.pdf", w = 8, h = 6)

# Read your data from the file
data <- read.table("CHX_4hpf_vs_WT_4hpf.scatter.txt", header = TRUE, sep = "\t")

data1 <- data[data$WT >= 1 & data$Class != "Maternal_gene", ]
data2 <-rbind (data[data$Class == "Maternal_gene", ], data1)

# Create the scatter plot with different alpha values
ggplot(data2, aes(x = WT, y = Mutant, color = Class)) +
  geom_point(aes(alpha = Class), size = 4) +
  scale_color_manual(values = c('grey','#B02418','#000000')) +
  scale_alpha_manual(values = c(0.1, 0.8, 1)) +
  scale_x_continuous( breaks = c(0, 2,4,6,8,10,12,14))+
  scale_y_continuous( breaks = c(0, 2,4,6,8,10,12,14))+
  geom_abline(lty = 1) +
  #scale_alpha_manual(values = c('grey' = 0.1, '#E69F00' = 1, '#000000' = 1)) +  # Map alpha values to Class
  theme_classic()+ coord_fixed()

# Save the plot to the PDF file
dev.off()


# Set the output PDF file
pdf("CHX_6hpf_vs_WT_6hpf.scatter.pdf", w = 8, h = 6)

# Read your data from the file
data <- read.table("CHX_6hpf_vs_WT_6hpf.scatter.txt", header = TRUE, sep = "\t")

data1 <- data[data$WT >= 1 & data$Class != "Maternal_gene", ]
data2 <-rbind (data[data$Class == "Maternal_gene", ], data1)

# Create the scatter plot with different alpha values
ggplot(data2, aes(x = WT, y = Mutant, color = Class)) +
  geom_point(aes(alpha = Class), size = 4) +
  scale_color_manual(values = c('grey','#B02418','#000000')) +
  scale_alpha_manual(values = c(0.1, 0.8, 1)) +
  scale_x_continuous( breaks = c(0, 2,4,6,8,10,12,14))+
  scale_y_continuous( breaks = c(0, 2,4,6,8,10,12,14))+
  geom_abline(lty = 1) +
  #scale_alpha_manual(values = c('grey' = 0.1, '#E69F00' = 1, '#000000' = 1)) +  # Map alpha values to Class
  theme_classic()+ coord_fixed()

# Save the plot to the PDF file
dev.off()




# Set the output PDF file
pdf("tri_res_4hpf_vs_WT_4hpf.scatter.pdf", w = 8, h = 6)

# Read your data from the file
data <- read.table("tri_res_4hpf_vs_WT_4hpf.scatter.txt", header = TRUE, sep = "\t")

# Create the scatter plot with different alpha values
ggplot(data, aes(x = WT, y = Mutant, color = Class)) +
  geom_point(aes(alpha = Class), size = 4) +
  scale_color_manual(values = c('grey','#B02418','#000000')) +
  scale_alpha_manual(values = c(0.1, 0.8, 1)) +
  scale_x_continuous( breaks = c(0, 2,4,6,8,10,12,14))+
  scale_y_continuous( breaks = c(0, 2,4,6,8,10,12,14))+
  geom_abline(lty = 1) +
  #scale_alpha_manual(values = c('grey' = 0.1, '#E69F00' = 1, '#000000' = 1)) +  # Map alpha values to Class
  theme_classic()+ coord_fixed()

# Save the plot to the PDF file
dev.off()

# Set the output PDF file
pdf("tri_res_6hpf_vs_WT_6hpf.scatter.pdf", w = 8, h = 6)

# Read your data from the file
data <- read.table("tri_res_6hpf_vs_WT_6hpf.scatter.txt", header = TRUE, sep = "\t")

# Create the scatter plot with different alpha values
ggplot(data, aes(x = WT, y = Mutant, color = Class)) +
  geom_point(aes(alpha = Class), size = 4) +
  scale_color_manual(values = c('grey','#B02418','#000000')) +
  scale_alpha_manual(values = c(0.1, 0.8, 1)) +
  scale_x_continuous( breaks = c(0, 2,4,6,8,10,12,14))+
  scale_y_continuous( breaks = c(0, 2,4,6,8,10,12,14))+
  geom_abline(lty = 1) +
  #scale_alpha_manual(values = c('grey' = 0.1, '#E69F00' = 1, '#000000' = 1)) +  # Map alpha values to Class
  theme_classic()+ coord_fixed()

# Save the plot to the PDF file
dev.off()

# Set the output PDF file
pdf("tri_res_8hpf_vs_WT_8hpf.scatter.pdf", w = 8, h = 6)

# Read your data from the file
data <- read.table("tri_res_8hpf_vs_WT_8hpf.scatter.txt", header = TRUE, sep = "\t")

# Create the scatter plot with different alpha values
ggplot(data, aes(x = WT, y = Mutant, color = Class)) +
  geom_point(aes(alpha = Class), size = 4) +
  scale_color_manual(values = c('grey','#B02418','#000000')) +
  scale_alpha_manual(values = c(0.1, 0.8, 1)) +
  scale_x_continuous( breaks = c(0, 2,4,6,8,10,12,14))+
  scale_y_continuous( breaks = c(0, 2,4,6,8,10,12,14))+
  geom_abline(lty = 1) +
  #scale_alpha_manual(values = c('grey' = 0.1, '#E69F00' = 1, '#000000' = 1)) +  # Map alpha values to Class
  theme_classic()+ coord_fixed()

# Save the plot to the PDF file
dev.off()


# Set the output PDF file
pdf("tri_4hpf_vs_WT_4hpf.scatter.pdf", w = 8, h = 6)

# Read your data from the file
data <- read.table("tri_4hpf_vs_WT_4hpf.scatter.txt", header = TRUE, sep = "\t")

# Create the scatter plot with different alpha values
ggplot(data, aes(x = WT, y = Mutant, color = Class)) +
  geom_point(aes(alpha = Class), size = 4) +
  scale_color_manual(values = c('grey','#B02418','#000000')) +
  scale_alpha_manual(values = c(0.1, 0.8, 1)) +
  scale_x_continuous( breaks = c(0, 2,4,6,8,10,12,14))+
  scale_y_continuous( breaks = c(0, 2,4,6,8,10,12,14))+
  geom_abline(lty = 1) +
  #scale_alpha_manual(values = c('grey' = 0.1, '#E69F00' = 1, '#000000' = 1)) +  # Map alpha values to Class
  theme_classic()+ coord_fixed()

# Save the plot to the PDF file
dev.off()


# Set the output PDF file
pdf("tri_6hpf_vs_WT_6hpf.scatter.pdf", w = 8, h = 6)

# Read your data from the file
data <- read.table("tri_6hpf_vs_WT_6hpf.scatter.txt", header = TRUE, sep = "\t")

# Create the scatter plot with different alpha values
ggplot(data, aes(x = WT, y = Mutant, color = Class)) +
  geom_point(aes(alpha = Class), size = 4) +
  scale_color_manual(values = c('grey','#B02418','#000000')) +
  scale_alpha_manual(values = c(0.1, 0.8, 1)) +
  scale_x_continuous( breaks = c(0, 2,4,6,8,10,12,14))+
  scale_y_continuous( breaks = c(0, 2,4,6,8,10,12,14))+
  geom_abline(lty = 1) +
  #scale_alpha_manual(values = c('grey' = 0.1, '#E69F00' = 1, '#000000' = 1)) +  # Map alpha values to Class
  theme_classic()+ coord_fixed()

# Save the plot to the PDF file
dev.off()

# Set the output PDF file
pdf("tri_8hpf_vs_WT_8hpf.scatter.pdf", w = 8, h = 6)

# Read your data from the file
data <- read.table("tri_8hpf_vs_WT_8hpf.scatter.txt", header = TRUE, sep = "\t")

# Create the scatter plot with different alpha values
ggplot(data, aes(x = WT, y = Mutant, color = Class)) +
  geom_point(aes(alpha = Class), size = 4) +
  scale_color_manual(values = c('grey','#B02418','#000000')) +
  scale_alpha_manual(values = c(0.1, 0.8, 1)) +
  scale_x_continuous( breaks = c(0, 2,4,6,8,10,12,14))+
  scale_y_continuous( breaks = c(0, 2,4,6,8,10,12,14))+
  geom_abline(lty = 1) +
  #scale_alpha_manual(values = c('grey' = 0.1, '#E69F00' = 1, '#000000' = 1)) +  # Map alpha values to Class
  theme_classic()+ coord_fixed()

# Save the plot to the PDF file
dev.off()



