#install.packages("ggcorrplot")
library(reshape2)
library(ggplot2)
library(RColorBrewer)
library(ggcorrplot)


setwd("/Users/li243/OSUMC/my_project/TE_activation/01_final_work_dir/03_TE_activation/03_newlyActivatedTE/nearStageCorrelation")
data <- read.table("TE_trans.final.cpm.noRep.matrix", header=T, row.names=1, com='', quote='', check.names=F, sep="\t")
cormat <- round(cor(data, method="pearson"),2)
melted_cormat <- melt(cormat)

pdf("TE_trans.final.cpm.noRep.matrix.pearson.lower.1.pdf", pointsize=5)

ggcorrplot(cormat, hc.order = FALSE, type = "lower",
            outline.col = "white", lab=TRUE, lab_col="black")+
  #scale_fill_gradientn(colours = colorspace::diverge_hcl(7))+
  #scale_fill_gradient(low = "white", high = "#A9D18E")+
  #scale_fill_gradient2(low = "grey",mid = "white", high ="#A9D18E",midpoint=0.2 )+
  scale_fill_gradientn(colours = colorspace::sequential_hcl(7, h = c(260, 60), c = 60, l = c(40, 95), power = 1))+
  #scale_fill_gradient2(low = "#A9D18E",mid = "white", high = "grey",midpoint=0.2 )+
  theme_classic()+
  theme(axis.text.x = element_text(angle = 45, vjust = 1, 
    size = 14, hjust = 1))+theme(axis.text.y = element_text(size = 14, hjust = 1))
                                                      
dev.off()


data <- read.table("Gene_trans.final.cpm.noRep", header=T, row.names=1, com='', quote='', check.names=F, sep="\t")
cormat <- round(cor(data, method="pearson"),2)
melted_cormat <- melt(cormat)

pdf("Gene_trans.final.cpm.noRep.matrix.pearson.lower.1.pdf", pointsize=5)

ggcorrplot(cormat, hc.order = FALSE, type = "lower",
            outline.col = "white", lab=TRUE, lab_col="black")+
  #scale_fill_gradientn(colours = colorspace::diverge_hcl(7))+
  #scale_fill_gradient2(low = "grey",mid = "white", high ="#A9D18E",midpoint=0.05 )+
  scale_fill_gradientn(colours = colorspace::sequential_hcl(7, h = c(260, 60), c = 60, l = c(40, 95), power = 1))+
  theme_classic()+
  theme(axis.text.x = element_text(angle = 45, vjust = 1, 
    size = 14, hjust = 1))+theme(axis.text.y = element_text(size = 14, hjust = 1))
                                                      
dev.off()

data <- read.table("TE-Gene_trans.final.cpm.noRep", header=T, row.names=1, com='', quote='', check.names=F, sep="\t")
cormat <- round(cor(data, method="pearson"),2)
melted_cormat <- melt(cormat)

pdf("TE-Gene_trans.final.cpm.noRep.matrix.pearson.lower.1.pdf", pointsize=5)

ggcorrplot(cormat, hc.order = FALSE, type = "lower",
            outline.col = "white", lab=TRUE, lab_col="black")+
  scale_fill_gradientn(colours = colorspace::sequential_hcl(7, h = c(260, 60), c = 60, l = c(40, 95), power = 1))+
  #scale_fill_gradient2(low = "grey",high ="#0DD10E",midpoint=0.05 )+
  theme_classic()+
  theme(axis.text.x = element_text(angle = 45, vjust = 1, 
    size = 14, hjust = 1))+theme(axis.text.y = element_text(size = 14, hjust = 1))
                                                      
dev.off()

